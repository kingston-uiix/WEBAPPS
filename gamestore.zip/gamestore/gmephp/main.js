
let id = $("input[name*='game_id']")
id.attr("readonly", "readonly");


$(".btnedit").click(e => {
    let textvalues = displayData(e);

    ;
    let gamename = $("input[name*='game_name']");
    let gameplat = $("input[name*='game_plat']");
    let gameconsole = $("input[name*='game_console']");
    let gamecate = $("input[name*='game_cate']");

    id.val(textvalues[0]);
    gamename.val(textvalues[1]);
    gameplat.val(textvalues[2]);
    gameconsole.val(textvalues[3]);
    gamecate.val(textvalues[4]);
});


function displayData(e) {
    let id = 0;
    const td = $("#tbody tr td");
    let textvalues = [];

    for (const value of td) {
        if (value.dataset.id == e.target.dataset.id) {
            textvalues[id++] = value.textContent;
        }
    }
    return textvalues;

}