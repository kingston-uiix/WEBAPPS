<?php 
  session_start(); 

  if (!isset($_SESSION['email'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['email']);
  	header("location: login.php");
  }
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css"
        integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">


    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <header>
        <div class="containerow">
            <div class="row">
                <div class="col-md-4 col-sm-12 col-12">
                    <div class="btn-group">
                        <button class="btn border dropdown-toggle my-md-4 my-2" data-toggle="dropdown"
                            area-haspopup="true" area-expanded="false">USD</button>
                        <div class="dropdown-menu">
                            <a href="" class="dropdown-item">ERU-Euro</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-12 text-center">
                    <a class="navbar-brand" href="#"><img src="logomaker.png" alt="logo" height="53" width="190"></a>
                </div>
                <div class="col-md-4 col-12 text-right">
                    <p class="my-md-4 header-links">
                        <a href="login.php" class="px-2">Logout</a>
                    </p>
                </div>
            </div>
        </div>
    </header>


    <section class="navigation">
        <div class="nav-container">
            <div class="brand">
                <a href="#!"><img src="logo.png" alt="logo" height="53" width="190"></a>
            </div>
            <nav>
                <div class="nav-mobile">
                    <a id="nav-toggle" href="#!"><span></span></a>
                </div>
                <ul class="nav-list">
                    <!-- Setting the links to #! will ensure that no action takes place on click. -->
                    <li><a href="gmeind.php">Games</a></li>
                    <li><a href="buyind.php">Buyers</a></li>
                    <li><a href="selind.php">Sellers</a></li>
                    <li><a href="#!">Details </a></li>
                    <li><a href="#!">Contact</a></li>
                </ul>
            </nav>
        </div>
    </section>



    <h2 style="text-align:center; padding-top:1rem; text-transform:uppercase; color:green;">Details of Game Buyers
        and
        Sellers </h2>

    <div class="containerrr">

        <div class="col-md-4 offset-md-4 mt-5 border border-success pt-3">
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="myInput" placeholder="Search ......"
                    aria-label="Recipient's username">
                <div class="input-group-append">
                    <span class="input-group-text"><i class="fa fa-search"></i></span>
                </div>
            </div>
        </div>

        <table class="content-table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Game</th>
                    <th>Buyer</th>
                    <th>Seller</th>
                </tr>
            </thead>
            <tbody id=myTable>
                <tr>
                    <td>1</td>
                    <td>GTA V</td>
                    <td>Manu</td>
                    <td>Rajesh</td>
                </tr>
                <tr class="active-row">
                    <td>2</td>
                    <td>God of war</td>
                    <td>Kingston</td>
                    <td>Venkat</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Call of duty</td>
                    <td>Bosco</td>
                    <td>Router</td>
                </tr>
                <tr class="active-row">
                    <td>4</td>
                    <td>Call of duty</td>
                    <td>allen killer</td>
                    <td>Router</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>game thrones</td>
                    <td>Bosco</td>
                    <td>vicky</td>
                </tr>
                <tr class="active-row">
                    <td>6</td>
                    <td>Frends</td>
                    <td>joe</td>
                    <td>roshan</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>vice city</td>
                    <td>king</td>
                    <td>manu</td>
                </tr>
                <tr class="active-row">
                    <td>8</td>
                    <td>Dota 2</td>
                    <td>ramu</td>
                    <td>prateek</td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>PUBG</td>
                    <td>joe</td>
                    <td>Likhith</td>
                </tr>

            </tbody>
        </table>


    </div>

    <div class="container">
        <div class="box">
            <div class="icon">
                <i class="fa fa-gamepad" aria-hidden="true"></i>
            </div>
            <div class="content">
                <h3>Games</h3>
                <p>Welcome to game database where you can view detals of games.</p>
            </div>
        </div>
        <div class="box">
            <div class="icon">
                <i class="fa fa-user" aria-hidden="true"></i>
            </div>
            <div class="content">
                <h3>Buyers</h3>
                <p>Welcome to game database where you can view detals of game buyers.</p>
            </div>
        </div>
        <div class="box">
            <div class="icon">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
            </div>
            <div class="content">
                <h3>Sellers</h3>
                <p>Welcome to game database where you can view detals of games sellers .</p>
            </div>
        </div>
    </div>


    <footer class="footer-distributed">

        <div class="footer-right">

            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-linkedin"></i></a>


        </div>

        <div class="footer-left">

            <p class="footer-links">
                <a class="link-1" href="#">Home</a>

                <a href="#">Blog</a>

                <a href="#">Pricing</a>

                <a href="#">About</a>

                <a href="#">Faq</a>

                <a href="#">Contact</a>
            </p>

            <p>Kingston David &copy; 2018</p>
        </div>

    </footer>



    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
    <script src="ind.js"></script>
</body>

</html>