
let id = $("input[name*='sel_id']")
id.attr("readonly", "readonly");


$(".btnedit").click(e => {
    let textvalues = displayData(e);

    ;
    let selname = $("input[name*='sel_name']");
    let selmail = $("input[name*='sel_mail']");
    let buyid = $("input[name*='buy_id']");


    id.val(textvalues[0]);
    selname.val(textvalues[1]);
    selmail.val(textvalues[2]);
    buyid.val(textvalues[3]);

});


function displayData(e) {
    let id = 0;
    const td = $("#tbody tr td");
    let textvalues = [];

    for (const value of td) {
        if (value.dataset.id == e.target.dataset.id) {
            textvalues[id++] = value.textContent;
        }
    }
    return textvalues;

}